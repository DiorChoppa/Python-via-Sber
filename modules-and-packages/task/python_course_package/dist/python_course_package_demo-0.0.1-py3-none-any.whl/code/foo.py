class NewFooClass:
    def print_smth(self):
        print("Hello world!")